########################
## HQ Zone XBMC AddON ##
########################

Released - 15/11/14

Addon was created from mashup source code, all code credits belong to Mash2K3.

XBMC Addon created from Mashup source code by mFuk.

Copyright HQZone.tv

Visit hqzone.tv today and sign up for our sports packs encluding PPV events & Video On Demand.