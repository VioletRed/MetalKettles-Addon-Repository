import xbmc,xbmcaddon,xbmcgui,xbmcplugin,urllib,urllib2,os,re,sys,datetime,shutil
 
SiteName='UltraBox  [v0.0.1]  [Movies-TV]'
bvtube ='http://boxingvideostube.com/'
saddo = 'http://www.saddoboxing.com/boxing-videos/Boxing/page1.html'
saddobase = 'http://www.saddoboxing.com/boxing-videos/'
addon_id = 'plugin.video.ultrabox'
selfAddon = xbmcaddon.Addon(id=addon_id)
global name3
name3 = '0'

def INDEX():
        addDir('Boxing VideoTube',bvtube,1,'http://i1.ytimg.com/vi/yHSrSchz8Kc/maxresdefault.jpg')
        addDir('Saddo Boxing',saddo,3,'http://www.saddoboxing.com/boxing-news/boxinglogo.gif')
        addDir('Ultrabox Mega Search','url',5,'http://m-y-d-s.com/en/martial_arts/boxing_glove/a.jpg')       
        addDir('Boxing Podcasts','url',6,'http://evepodcasts.com/wp-content/uploads/2012/05/podcast-headphones.png')
        #addDir('Boxing News','',7,'')
        
def GETBVTUBEFIGHTERS(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('class="dir">(.+?)\n\t\t<ul>').findall(link)
        for name in match:
                print name
                addDir(name,bvtube,2,'http://i1.ytimg.com/vi/yHSrSchz8Kc/maxresdefault.jpg')

def GETBVTUBEIGHTS(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<li><a href="(.+?)">(.+?) vs. (.+?)</a></li>').findall(link)
        for url, fighter, opp in match:
                print url
                if fighter == name:
                       addDir(fighter + ' vs ' + opp,url,50,'http://i1.ytimg.com/vi/yHSrSchz8Kc/maxresdefault.jpg')
def SADDOCATS(url):
        addDir('Browse Saddo Boxing',saddo,4,'http://www.saddoboxing.com/boxing-news/boxinglogo.gif')
        addDir('Search Saddo Boxing....',saddo,80,'http://www.saddoboxing.com/boxing-news/boxinglogo.gif')


def SADDOFIGHTS(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('<h3><a href="(.+?)">(.+?)</a></h3>\n\n      <a href=".+?"><img src="(.+?)"').findall(link)
        for url, name, thumb in match:
            test = url.split ('/',2)
            youtube_id = test[1]
            url = 'plugin://plugin.video.youtube/?path=root/video&action=play_video&videoid=%s' % youtube_id
            addDir(name,url,70,thumb)
        match=re.compile('<p class="next_page"><a href="(.+?)">Next Page</a></p>').findall(link)
        for url in match:
               addDir ('Next Page....',saddobase + url,4,'')
            
def PLAYBVTUBE(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile('&file=(.+?)&autostart=true&stretching=exactfit').findall(link)
        for url in match:
                print url
                xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
                xbmcPlayer.play(url)
                exit()
                 
def PLAYYOUTUBE(url):
        xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
        xbmcPlayer.play(url)
        exit()

def SEARCHSADDO():
    search_entered =''
    keyboard = xbmc.Keyboard(search_entered, 'test')
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_entered = keyboard.getText().replace(' ','+')# sometimes you need to replace spaces with + or %20#
    if search_entered == None or len(search_entered)<1:
        end()
    else:
        url = 'http://www.saddoboxing.com/boxing-videos/list.php?q='+ search_entered + '&Submit=GO'
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    match=re.compile('<h3><a href="(.+?)">(.+?)</a></h3>\n\n      <a href=".+?"><img src="(.+?)"').findall(link)
    for url, name, thumb in match:
            test = url.split ('/',2)
            youtube_id = test[1]
            url = 'plugin://plugin.video.youtube/?path=root/video&action=play_video&videoid=%s' % youtube_id
            addDir(name,url,70,thumb)
    match=re.compile('<p class="next_page"><a href="(.+?)">Next Page</a></p>').findall(link)
    for url in match:
                    addDir ('Next Page....',saddobase + url,4,'')
        
def MEGASEARCH(url):
    search_entered =''
    keyboard = xbmc.Keyboard(search_entered, 'test')
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_entered = keyboard.getText().replace(' ','+')# sometimes you need to replace spaces with + or %20#
    if search_entered == None or len(search_entered)<1:
        end()
    else:
        url='https://gdata.youtube.com/feeds/api/videos?q=' + search_entered + '&start-index=1&max-results=50&v=2'
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile("label='Sports'/><title>(.+?)</title><content type='application/x-shockwave-flash' src='(.+?)?version=3&amp;f=videos&amp;app=youtube_gdata'/>").findall(link)
        for name, url in match:
                youtubeid = url.split('https://www.youtube.com/v/',2)
                youtube_id = youtubeid[1].replace('?','')
                url = 'plugin://plugin.video.youtube/?path=root/video&action=play_video&videoid=%s' % youtube_id
                print url
                addDir(name,url,70,'http://m-y-d-s.com/en/martial_arts/boxing_glove/a.jpg')
                
def PODCASTS(url):
         addDir('ESPN','http://sports.espn.go.com/espnradio/podcast/feeds/itunes/podCast?id=3417454',7,'http://assets.espn.go.com/i/espnradio/podcast/heavyHitting_300.jpg')
         addDir('Yahoo Sports','http://www.yahoosportsradio.com/media/podcast/mouthpiece.rss',8,'http://findlogo.net/images/Y/yahoo%20sports%20logo.jpg')

def GETESPN(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile("<title>(.+?)</title>\n                                <link>(.+?)</link>").findall(link)
        for title, mp3 in match:
            url = mp3.replace ('<![CDATA[','').replace(']]>','')
            addDir(title,url,70,'http://assets.espn.go.com/i/espnradio/podcast/heavyHitting_300.jpg')
            
def GETYAHOO(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        response = urllib2.urlopen(req)
        link=response.read()
        response.close()
        match=re.compile("<title>(.+?)</title>\r\n      <link>(.+?)</link>").findall(link)
        for title, mp3 in match:
            addDir(title,mp3,70,'http://findlogo.net/images/Y/yahoo%20sports%20logo.jpg')
                
def PLAYLINK(name,url):
        playlist = xbmc.PlayList(1)
        playlist.clear()
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png")
        listitem.setInfo("Video", {"Title":name})
        listitem.setProperty('mimetype', 'video/x-msvideo')
        listitem.setProperty('IsPlayable', 'true')
        stream_url = urlresolver.HostedMediaFile(url).resolve()
        playlist.add(stream_url,listitem)
        xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
        xbmcPlayer.play(playlist)
        exit()

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                               
        return param
               
def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz)
        return ok
 
 
def addDir(name,url,mode,iconimage,isFolder=True):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&site="+str(site)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=isFolder)
        return ok
 
 
params=get_params(); url=None; name=None; mode=None; site=None
try: site=urllib.unquote_plus(params["site"])
except: pass
try: url=urllib.unquote_plus(params["url"])
except: pass
try: name=urllib.unquote_plus(params["name"])
except: pass
try: mode=int(params["mode"])
except: pass
 
print "Site: "+str(site); print "Mode: "+str(mode); print "URL: "+str(url); print "Name: "+str(name)
 
if mode==None or url==None or len(url)<1: INDEX()
elif mode==1: GETBVTUBEFIGHTERS(url)
elif mode==2: GETBVTUBEIGHTS(url)
elif mode==3: SADDOCATS(url)
elif mode==4: SADDOFIGHTS(url)
elif mode==5: MEGASEARCH(url)
elif mode==6: PODCASTS(url)
elif mode==7: GETESPN(url)
elif mode==8: GETYAHOO(url)
elif mode==50: PLAYBVTUBE(url)
elif mode==70: PLAYYOUTUBE(url)
elif mode==80: SEARCHSADDO()
elif mode==100: VIDEOLINKS(url,name)
elif mode==200: PLAYLINK(name,url)
xbmcplugin.endOfDirectory(int(sys.argv[1]))
